# Telegram-Pay
 Telegram Pay to'lov tizimi uchun namuna

Telegramdan chiqmasdan turib mahsulot va xizmatlarga to'lov qilishni osoni usuli.
Buni uchun sizda **Click.uz** yoki **Payme.uz** bilan shartnoma qilishingiz kerak bo'ladi.

* config.php fayliga kerak bo'ladigan o'zgaruvchilarni kiritasiz:
1.  $bot_token - ga @BotFather dan olingan botni tokenini
2.  $provider_token - ga esa @CLICKTerminal yoki @CLICKTerminal olingan tokenni kiritasiz.


* Shunchaki TEST qilib ko'rmoqchi bo'lsangiz:
1. @CLICKtest dan TEST token olishingiz mumkin.

🔗 To'lov haqida batafsil: https://core.telegram.org/bots/payments

💻 Dasturchi: https://t.me/ads_buy

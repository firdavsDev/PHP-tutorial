<?php 
/**
 * @pcode uchun Telegram Pay kodi
 * @author ShaXzod Jomurodov <shah9409@gmail.com>
 * @contact https://t.me/idFox AND https://t.me/ads_buy
 * @date 13.05.2021 15:21
 */

ini_set('date.timezone','ASIA/Tashkent');

$bot_token = 'bot_token';
$provider_token  = '398062629:TEST:999999999_F91D8F69C042267444B74CC0B3C747757EB0E065';
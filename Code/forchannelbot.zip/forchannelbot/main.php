<?php
date_default_timezone_set("asia/Tashkent");
$admin = '1328953019';
$token = '🧐😂';

function bot($method,$datas=[]){
global $token;
    $url = "https://api.telegram.org/bot".$token."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res); 
    }
}
include ("connect.php");
function joinchat($from){
     global $message_id;
     $gett = bot('getChatMember',[
  'chat_id' =>"-1001130268536",
  'user_id' => $from,
  ]);
  $stat = $gett->result->status;
if($stat=="creator" or $stat=="administrator" or $stat=="member"){
      return true;
         }else{
           bot('deleteMessage',[
'chat_id'=>$from,
'message_id'=>$mid-2,
]);
bot('sendmessage',[
         'chat_id'=>$from,
         'text'=>"<b>🤖: Men orqali kanalingiz postlariga ishlov berishingiz mumkin

Foydalanishdan avval quyidagi kanallarga obuna bo'ling aks holda bot ishlamaydi❗️

Agar kanallardan chiqib ketsangiz bot ishlamay qoladi shuning uchun kanalni tark etmang❗

Kanalga a'zo bo'lib qayta /start bosing !</b>",
         'parse_mode'=>'html',
         'reply_to_message_id'=>$mid,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'ᴍʏ ᴘᴏʀᴛғᴏʟɪᴏ','url'=>"https://t.me/DunyoFaktlariTv"]],
]
]),
]);   
return false;
}
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$tx = $message->text;
$cid = $update->message->chat->id;
$mid = $message->message_id;
$type = $update->message->chat->type;
$name = $update->message->from->first_name;
$fromid = $message->from->id;
#===========(@LiderKoder)=========#
include ("keyboard.php");
#Callback
$data = $update->callback_query->data;
$mid2 = $update->callback_query->message->message_id;
$cid2 = $update->callback_query->message->chat->id;
$fromid2 = $update->callback_query->message->from->id;
$name2 = $update->callback_query->from->first_name;  
$qid = $update->callback_query->id; 
#===========(@LiderKoder)=========#
$sticker = $message->sticker;
$sticker_id = $message->sticker->file_id;
$voice = $message->voice;
$voice_id = $message->voice->file_id;
$file = $message->document;
$file_id = $message->document->file_id;
$audio = $message->audio;
$audio_id = $message->audio->file_id;
$video = $message->video;
$video_id = $message->video->file_id;
$photo = $message->photo;
$photo_id = $message->photo[0]->file_id;
$videonote = $message->video_note;
$videonote_id = $message->video_note->file_id;
#===========(@LiderKoder)=========#
$kanal = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM channel WHERE creator = '$fromid' LIMIT 1"));
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$fromid' LIMIT 1"));
$user2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$fromid2' LIMIT 1"));

#===========(@LiderKoder)=========#
$useri = $kanal['user'];
$nomi = $kanal['name'];
$id = $kanal['channel_id'];
#===========(@LiderKoder)=========#
$channel = $update->channel_post; 
$channel_text = $channel->text;
$channel_mid = $channel->message_id; 
$channel_id = $channel->chat->id; 
$channel_user = $channel->chat->username; 
$rek = file_get_contents('rek.txt');
#===========(@LiderKoder)=========#
$sana = date('d.m.Y');
$soat = date('H:i:s');
#===========(@LiderKoder)=========#

if($channel and $channel_id == "-1001130268536"){
file_put_contents('rek.txt',$channel_mid);
}


function SendSingle($cid,$mid,$type,$messagefile,$captionhed="",$parse_mode="null",$sorov=""){
if($type == "photo"){
          bot('sendphoto',[
       'chat_id'=>$cid,
       'photo'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);

}
if($type == "video"){
            bot('sendvideo',[
       'chat_id'=>$cid,
       'video'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "audio"){
            bot('sendaudio',[
       'chat_id'=>$cid,
       'audio'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "document"){
            bot('senddocument',[
       'chat_id'=>$cid,
       'document'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "voice"){
            bot('sendvoice',[
       'chat_id'=>$cid,
       'voice'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "sticker"){
            bot('sendsticker',[
       'chat_id'=>$cid,
       'sticker'=>$messagefile,
       'reply_markup'=>$sorov
            ]);
}
if($type == "videonote" ){
            bot('sendVideoNote',[
       'chat_id'=>$cid,
       'video_note'=>$messagefile,
       'reply_markup'=>$sorov
            ]);
}

if($type == "text"){
            bot('sendMessage',[
       'chat_id'=>$cid,
       'text'=>"$messagefile",
     'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
}


function Kanal($cid='',$mid='',$type="",$messagefile="",$captionhed="",$parse_mode=null,$sorov=""){
if($type == "photo"){
          $h = bot('sendphoto',[
       'chat_id'=>$cid,
       'photo'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "video"){
           $h = bot('sendvideo',[
       'chat_id'=>$cid,
       'video'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "audio"){
           $h = bot('sendaudio',[
       'chat_id'=>$cid,
       'audio'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "document"){
          $h = bot('senddocument',[
       'chat_id'=>$cid,
       'document'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "voice"){
           $h = bot('sendvoice',[
       'chat_id'=>$cid,
       'voice'=>$messagefile,
       'caption' => $captionhed,
       'parse_mode'=>$parse_mode,
              'reply_markup'=>$sorov
            ]);
}
if($type == "sticker"){
           $h = bot('sendsticker',[
       'chat_id'=>$cid,
       'sticker'=>$messagefile,
       'reply_markup'=>$sorov
            ]);
}
if($type == "videonote" ){
            $h = bot('sendVideoNote',[
       'chat_id'=>$cid,
       'video_note'=>$messagefile,
       'reply_markup'=>$sorov
            ]);
}

if($type == "text"){
$h= bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>$messagefile,
'parse_mode'=>$parse_mode,
  'reply_markup'=>$sorov
]);
} 
return $h;
}

echo Kanal($cid,$mid,$type,$messagefile,$captionhed,$parse_mode,$sorov)["result"]["message_id"];

// Keyboard yaratadigan funksiya
function replyKeyboard($keyboard) {
    return json_encode([
        'resize_keyboard'=>true,
        'keyboard'=> $keyboard
    ]);
}

// Keyboard yaratish
$main = replyKeyboard([
    [['text'=>"® Post yaratish"],['text'=>"📖 Qo'llanma"]],
    [['text'=>"⚙️ Sozlamalar"],['text'=>"📣 Mening kanalim"]],
    [['text'=>"📞Aloqa"],['text'=>"📊 Statistika"]],
]);
$main2 = replyKeyboard([
    [['text'=>"➕ Kanal ulash"],['text'=>"📖 Qo'llanma"]],
    [['text'=>"📞Aloqa"],['text'=>"📊 Statistika"]],
]);

$addchannel = replyKeyboard([
[['text'=>"➕ Kanal ulash"],['text'=>"↩️ Orqaga"]],
]);

$cancell = replyKeyboard([
[['text'=>"🚫 Cancell ⛔"]],
]);

$boshmenyu = replyKeyboard([
[['text'=>"↩️ Orqaga"]],
]);

$sorov = json_encode([
"resize_keyboard"=>true,
"inline_keyboard"=>[
[["text"=>"🖼Caption qo'shish ➕","callback_data"=>"caption"],["text"=>"🔘Yashrin tugma➕","callback_data"=>"yashirin"],],
[["text"=>"🔀Ulashish qo'shish➕","callback_data"=>"ulash"],["text"=>"❤Like qo'shish ➕","callback_data"=>"like"]],
[['text'=>'❌Bekor qilish','callback_data'=>'x'],["text"=>"Tayyor✅","callback_data"=>"tayyor"],],
]
]);

if($tx=="🚫 Cancell ⛔"){
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$fromid'");
mysqli_query($connect,"DELETE FROM post WHERE status ='no'");
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Bekor qilindi

Bosh menyu</b>",
'parse_mode'=>'html',
'reply_markup'=>$main,
]);
}

if(isset($tx)){
if($type == "private"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE user_id= $fromid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO users(user_id,mode) VALUES ('$fromid','null')");
}
}
}


if($channel_text == "#on"){
$result = mysqli_query($connect,"SELECT * FROM channels WHERE channel_id = $channel_id");
$rew = mysqli_fetch_assoc($result);
if($rew){
bot('deletemessage',[
	'chat_id'=>$channel_id,
	'message_id'=>$channel_mid,
]);
}else{
mysqli_query($connect,"INSERT INTO channels(channel_id,status) VALUES ('$channel_id','on')");
bot('deletemessage',[
	'chat_id'=>$channel_id,
	'message_id'=>$channel_mid,
]);
}
}

if($tx=="/start" or $tx=="↩️ Orqaga"){
if(joinchat($cid)=="true"){
if($kanal){
bot('forwardmessage',[
    'chat_id'=>$cid,
    'from_chat_id'=>"@dunyofaktlaritv",
    'message_id'=>$rek,
        ]);
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Assalomu alaykum $name 👋
Ushbu bot orqalik o'z kanalingiz uchun ajoyib postlar(<code>❤️ Kanalga azo bolmasa like bosa olmaydigan, yashirin javobli postlar👀</code>) tayorlashingiz mumkin!</b>

Marhamat kerakli bo'limni tanlang",
'parse_mode'=>'html',
'reply_markup'=>$main,
]);
}else{
bot('forwardmessage',[
    'chat_id'=>$cid,
    'from_chat_id'=>"@dunyofaktlaritv",
    'message_id'=>$rek,
        ]);
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Siz botga kanal ulamagansiz!</b>

Pastdagi <code>➕ Kanal ulash</code> tugmasini bosib kanalingizni ulang!",
'parse_mode'=>'html',
'reply_markup'=>$main2,
]);
}
}
}
if($tx=="📣 Mening kanalim"){
if($kanal){
	bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"*Kanalingiz ma'lumotlari:*
*User: @$useri*
*Nomi:* `$nomi` 
*ID:* `$id`",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📣 Kanalga o'tish","url"=>"https://t.me/$useri"]],
]
]),
]);
}else{
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Siz botga kanal ulamagansiz!</b>

Pastdagi <code>➕ Kanal ulash</code> tugmasini bosib kanalingizni ulang!",
'parse_mode'=>'html',
'reply_markup'=>$addchannel,
]);
}
}

if($tx=="➕ Kanal ulash"){
mysqli_query($connect,"UPDATE users SET step = 'kanal' WHERE user_id = '$fromid'");
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"🔯<b>Kanal userini (Namuna: @DunyoFaktlariTv) yuboring yoki kanalingizdan birorta postni Forward qiling</b>",
'parse_mode'=>'html',
'reply_markup'=>$boshmenyu,
]);
}

if($user['step'] =="kanal"){
if(strpos($tx,"@") !==false){
$us= bot('getChatMembersCount',[
'chat_id'=>$tx,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$tx,
]);
}else{
$forward_from_id = $message->forward_from_chat->id;
$us= bot('getChatMembersCount',[
'chat_id'=>$forward_from_id,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$forward_from_id,
]);
}
$kid = $getchat->result->id;
$kname = $getchat->result->title;
$kuser = $getchat->result->username;
$kty = $getchat->result->type;
if($kty == "channel"){
$result = mysqli_query($connect,"SELECT * FROM channel WHERE channel_id= $kid");
$rew = mysqli_fetch_assoc($result);
if($rew){
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"Ushbu kanal boshqa foydalanuvchi tomonidan botga qo'shilgan",
   'reply_markup'=>json_encode([
"inline_keyboard"=>[
[["text"=>"↩️ Bosh sahifa","callback_data"=>"home"]],
]
]),
]);
}else{
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"🆗 Kanalingiz haqida malumot!
Nomi➡️ $kname 👈
Useri➡️ @$kuser 👈
ID raqami➡️ $kid
A'zolar soni ➡ $count

✅ Tasdiqlash tugmasi orqali tasdiqlang.",
'parse_mode'=>'html',
 'reply_markup'=>json_encode([ 
        'inline_keyboard'=>[ 
       [['text'=>" ✅ Tasdiqlash ", 'callback_data'=>"kanal|$kid"]],
       ] 
       ])
]);
}
}
}


if((stripos($data,"kanal|")!==false)){
$ex = explode("|",$data);
	$px = $ex[1];
 $url = 'https://api.telegram.org/bot'.$token.'/getChatAdministrators?chat_id='.$px;
 $us= bot('getChatMembersCount',[
'chat_id'=>$px,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$px,
]);
$kid = $getchat->result->id;
$kname = $getchat->result->title;
$kuser = $getchat->result->username;
 $result = file_get_contents($url);
  $result = json_decode ($result);
  $ok = $result->ok;
$get_ = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$px&user_id=".$cid2);
$info_ = json_decode($get_, true);
$you_ = $info_['result']['status'];

if($ok == 'true' and $you_ == "creator" or $you_ == "administrator"){
mysqli_query($connect,"INSERT INTO channel (`creator`,`channel_id`,`name`,`count`,`user`) VALUES  ('$cid2','".$px."','".$kname."','".$count."','".$kuser."')");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$fromid2' LIMIT 1");
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
bot('sendmessage',[
        'chat_id'=>$cid2,
     'message_id'=>$mid2,
               'text'=>"✔<b>Kanalingiz muvaffaqiyatli qoshildi

🆗 Kanalingiz haqida malumot!</b>
📋<b> Nomi</b> $kname 👈
📧<b> Useri</b> @$kuser 👈
🆔<b> Raqami</b> $kid
👥<b>A'zolari</b> $count",
'parse_mode'=>'html',
    'reply_markup'=>$main,
]);
}else{
bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"📛Bot yoki siz kanalda admin emassiz!
 
Xatoni tog'irlab qayta ✅ Tasdiqlash tugmasini bosing☹️", 
        'show_alert'=>true, 
    ]);  
}
}
#Post yasash#
if($tx=="® Post yaratish"){
if(joinchat($cid)=="true"){
mysqli_query($connect,"UPDATE users SET step = 'post' WHERE user_id = '$fromid'");
bot('forwardmessage',[
    'chat_id'=>$cid,
    'from_chat_id'=>"@dunyofaktlaritv",
    'message_id'=>$rek,
        ]);
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*Marxamat post uchun rasm,matn,video,gif,musiqa lardan xoxlaganingizni yuboring*",
'parse_mode'=>'markdown',
'reply_markup'=>$cancell,
]);
}
}

#Asos#
if($user['step'] =="post" and $tx !=="🚫 Cancell ⛔"){
if($sticker){
$fileid = $sticker_id;
$type = "sticker";
$caption = $update->message->caption;
}
if($tx){
$tx = str_replace(["'"],["‘"],$tx);
$fileid = "$tx";
$type = "text";
}
if($voice){
$fileid = $voice_id;
$type = "voice";
$caption = $update->message->caption;
}
if($file){
$fileid = $file_id;
$type = "document";
$caption = $update->message->caption;
}
if($audio){
$fileid = $audio_id;
$type = "audio";
$caption = $update->message->caption;
}
if($video){
$fileid = $video_id;
$type = "video";
$caption = $update->message->caption;
}
if($photo){
$fileid = $photo_id;
$type = "photo";
$caption = $update->message->caption;
}
if($videonote){
$fileid = $videonote_id;
$type = "videonote";
$caption = $update->message->caption;
}

$style = $user["mode"];
if($style == "null"){
    $style = "";
}else{
    $style = $style;
}
mysqli_query($connect,"INSERT INTO post(`file`,`type`,`channel_id`,`caption`,`creator`,`status`) VALUES ('".$fileid."','$type','$id','$caption','$cid','no')");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$cid' LIMIT 1");
SendSingle($cid,$mid,$type,$fileid,$caption,$style,$sorov);
}

if($data=="caption"){
mysqli_query($connect,"UPDATE users SET step = 'caption' WHERE user_id = '$cid2' LIMIT 1");
bot('deletemessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendmessage',[
'chat_id'=>$cid2,
'text'=>"Marhamat caption matnini yuboring",
]);
}
if($user['step'] =="caption"){
	$capti = str_replace(["'"],["‘"],$tx);
mysqli_query($connect,"UPDATE post SET caption = '".$capti."' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$cid' LIMIT 1");
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$fromid' AND status = 'no' LIMIT 1"));
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'"));
$cap = $post['caption'];
$midd = $post['mid'];
$style = $user['mode'];
$typee = $post['type'];
$fileidd = $post['file'];

if($style == "null"){
    $style = "null";
}else {
    $style = $style;
}
SendSingle($cid,$midd,$typee,$fileidd,$cap,$style,$sorov);
}

if($data=="like"){
mysqli_query($connect,"UPDATE users SET step = 'like' WHERE user_id = '$cid2' LIMIT 1");
bot('deletemessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendmessage',[
'chat_id'=>$cid2,
'text'=>"*Marhamat like uchun emojilar yuboring!*

*Namuna:* `🤪/🧐/🤨`",
'parse_mode'=>'markdown',
]);
}
if($user['step'] =="like"){
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$fromid' AND status = 'no' LIMIT 1"));
$cap = $post['caption'];
$midd = $post['mid'];
$typee = $post['type'];
$fileidd = $post['file'];
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'"));
$style = $user['mode'];
if($style == "null"){
    $style = "null";
}else {
    $style = $style;
}
mysqli_query($connect,"UPDATE post SET emoji = '$tx' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$cid' LIMIT 1");
SendSingle($cid,$midd,$typee,$fileidd,$cap,$style,$sorov);
}

if($data=="ulash"){
mysqli_query($connect,"UPDATE users SET step = 'ulash' WHERE user_id = '$cid2' LIMIT 1");
bot('deletemessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendmessage',[
'chat_id'=>$cid2,
'text'=>"*Marhamat ulashish tugmasi uchun matn yuboring!*",
'parse_mode'=>'markdown',
]);
}
if($user['step'] =="ulash"){
$tx = str_replace(["'"],["‘"],$tx);
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$fromid' AND status = 'no' LIMIT 1"));
$cap = $post['caption'];
$midd = $post['mid'];
$typee = $post['type'];
$fileidd = $post['file'];
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'"));
$style = $user['mode'];
if($style == "null"){
    $style = "null";
}else {
    $style = $style;
}
mysqli_query($connect,"UPDATE post SET ulashish = '$tx' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$cid' LIMIT 1");
SendSingle($cid,$midd,$typee,$fileidd,$cap,$style,$sorov);
}

if($data=="yashirin"){
mysqli_query($connect,"UPDATE users SET step = 'tnomi' WHERE user_id = '$cid2' LIMIT 1");
bot('deletemessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendmessage',[
'chat_id'=>$cid2,
'text'=>"*Marhamat tugma uchun nom kiriting!*",
'parse_mode'=>'markdown',
]);
}
if($user['step'] =="tnomi"){
$tx = str_replace(["'"],["‘"],$tx);
mysqli_query($connect,"UPDATE post SET tugma = '$tx' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'emas' WHERE user_id = '$cid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*Endi kanalga a'zo bo'lmasa chiqadigan yozuvni yuboring*",
'parse_mode'=>'markdown',
]);
}
if($user['step'] =="emas"){
$tx = str_replace(["'"],["‘"],$tx);
mysqli_query($connect,"UPDATE post SET azo = '$tx' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'azo' WHERE user_id = '$cid' LIMIT 1");
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"*Endi kanalga a'zo bo'lgach chiqadigan yozuvni kiriting*",
'parse_mode'=>'markdown',
]);
}

if($user['step'] =="azo"){
$tx = str_replace(["'"],["‘"],$tx);
mysqli_query($connect,"UPDATE post SET javob = '$tx' WHERE creator = '$cid' AND status = 'no' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$cid' LIMIT 1");
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$fromid' AND status = 'no' LIMIT 1"));
$cap = $post['caption'];
$midd = $post['mid'];
$typee = $post['type'];
$fileidd = $post['file'];
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid'"));
$style = $user['mode'];
if($style == "null"){
    $style = "null";
}else {
    $style = $style;
}
SendSingle($cid,$midd,$typee,$fileidd,$cap,$style,$sorov);
}

$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$fromid2' AND status = 'no' LIMIT 1"));
$emoji = $post['emoji'];
$nomi = $post['tugma'];
$cap = $post['caption'];
$midd = $post['mid'];
$typee = $post['type'];
$fileidd = $post['file'];


if($data=="tayyor"){
$row2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM channel WHERE creator = '$cid2' LIMIT 1"));
$id = $row2['channel_id'];
$name = $row2['name'];
$user = $row2['user'];
$count = $row2['count'];
bot('deletemessage',[
        'chat_id'=>$cid2,
        'message_id'=>$mid2,
]);
bot('sendmessage',[
        'chat_id'=>$cid2,
        'message_id'=>$mid2,
 'text'=>"🚀 [$name](http://t.me/$user) *Post Kanaliga yuborildi*",
'disable_web_page_preview'=>true,
'parse_mode' => 'markdown',
        'reply_markup'=>$main,
        ]);
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE creator = '$cid2' AND status = 'no' LIMIT 1"));
$emoji = $post['emoji'];
$nomi = $post['tugma'];
$ulash = $post['ulashish'];
$cap = $post['caption'];
$midd = $post['mid'];
$typee = $post['type'];
$fileidd = $post['file'];
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE user_id = '$cid2'"));
$style = $user['mode'];
if($style == "null"){
    $style = "null";
}else {
    $style = $style;
}
           $tokenn=uniqid("true");
$key = [];

$ex = explode("/",$emoji); 
$soni = substr_count($emoji,"/");
if($soni > 0){
	foreach($ex as $emoj){
$uz[]=["text"=>"$emoj","callback_data"=>"$tokenn=$emoj"];
$key=array_chunk($uz, 5);
}
}
if($nomi !== "null"){
array_push($key,[['text' => "$nomi", 'callback_data' => "javob"]]);
}
if($ulash !== "null"){
array_push($key,[['text' => "$ulash", 'url' => "https://t.me/share/url?url=https://t.me/$user/$ok"]]);
}

$keyboard=json_encode([
'inline_keyboard'=>$key,
]);
 $json = Kanal($id,$midd,$typee,$fileidd,$cap,$style,$keyboard);
$ok = $json->result->message_id;
mysqli_query($connect,"UPDATE post SET mid = '$ok', token = '$tokenn', status = 'yes' WHERE creator = '$cid2' AND status = 'no' LIMIT 1");
SendSingle('-1001331007501',$midd,$typee,$fileidd,$cap,$style,$keyboard);
}

#Like bosish#
$callfrid = $update->callback_query->from->id; 
if(mb_stripos($data,"=")!==false){ 
$ret1 = bot("getChatMember",[
         "chat_id"=>$cid2,
         "user_id"=>$callfrid,
         ]);
  $stat1 = $ret1->result->status;
 if($stat1=="creator" or $stat1=="administrator" or $stat1=="member"){
$ex=explode("=",$data); 
$calltok=$ex[0]; 
$emoj=$ex[1]; 
$mylike=file_get_contents("like/$calltok.dat"); 
if(mb_stripos($mylike,"$callfrid")!==false){ 
      bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"Kechirasiz siz ovoz berib bo'lgansiz!", 
        'show_alert'=>false, 
    ]); 
}else{ 
file_put_contents("like/$calltok.dat","$mylike\n$callfrid=$emoj"); 
$value=file_get_contents("like/$calltok.dat"); 
$lik=substr_count($value,"👍"); 
$row2 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM channel WHERE channel_id = '$cid2' LIMIT 1"));
$id = $row2['channel_id'];
$name = $row2['name'];
$user = $row2['user'];
$count = $row2['count'];
$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE mid = '$mid2' AND status = 'yes' LIMIT 1"));
$emoji = $post['emoji'];
$nomi = $post['tugma'];
$ulash = $post['ulashish'];
$cap = $post['caption'];
$midd = $post['mid'];
$tokenn = $post['token'];

$key = [];

$ex = explode("/",$emoji); 
$soni = substr_count($emoji,"/");
if($soni > 0){
	foreach($ex as $emoj){
$value=file_get_contents("like/$calltok.dat"); 
$lik=substr_count($value,"$emoj"); 
$uz[]=["text"=>"$lik $emoj","callback_data"=>"$tokenn=$emoj"];
$key=array_chunk($uz, 5);
}
}
if($nomi !== "null"){
array_push($key,[['text' => "$nomi", 'callback_data' => "javob"]]);
}
if($ulash !== "null"){
array_push($key,[['text' => "$ulash", 'url' => "https://t.me/share/url?url=https://t.me/$user/$midd"]]);
}
     bot('editMessageReplyMarkup',[ 
        'chat_id'=>$cid2, 
        'message_id'=>$mid2,
        'inline_query_id'=>$qid,
        'reply_markup'=>json_encode([ 
        'inline_keyboard'=>$key
       ]) 
       ]);
       bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"Ovozingiz qabul qilindi!", 
        'show_alert'=>false, 
    ]);  
  }
 }else{
 bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"Ovoz berishingiz uchun kanalimiz obunachisi bo'lishingiz kerak!", 
        'show_alert'=>true, 
    ]);  
  }
}

$post = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM post WHERE mid = '$mid2'"));
$javob = $post['javob'];
$azo = $post['azo'];

if($data == "javob"){
$ret1 = bot("getChatMember",[
         "chat_id"=>$cid2,
         "user_id"=>$callfrid,
         ]);
  $stat1 = $ret1->result->status;
 if($stat1=="creator" or $stat1=="administrator" or $stat1=="member"){
 bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"$javob", 
        'show_alert'=>true, 
    ]); 	
}else{
bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>"$azo", 
        'show_alert'=>true, 
    ]);
}
}

if($data=="x"){ 
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
mysqli_query($connect,"DELETE FROM post WHERE creator = '$callfrid' AND status ='no'");
bot("sendmessage",[
"chat_id"=>$cid2,
"text"=>"🗑Post bekor qilindi",
"reply_markup"=>$main
]);
bot("answerCallbackQuery", [
"callback_query_id"=>$qid,
'text'=>"Bekor qilindi ✅",
"show_alert"=>true,
]);
}
#Ashnaqa#
if($tx == "📞Aloqa"){
if($type=="private"){
bot('sendmessage',[
'chat_id'=>$cid,
	"text"=>"*Assalomu Aleykum* [$name](tg://user?id=$cid)
*Bot admini: @LiderKoder*

`Sizga Xam turli xil botlar kerak bo'lsa bizga murojaat qiling`",
"parse_mode"=>'markdown',
     'reply_to_message_id'=>$mid,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"👨‍💻 ᴅᴀsᴛᴜʀᴄʜɪ", 'url'=>"https://t.me/LiderKoder"]],
]
]),
]);
}
}

 if($tx == "⚙️ Sozlamalar"){
$sql = "SELECT * FROM `users` WHERE `user_id`='$fromid' LIMIT 1";
$query = mysqli_query($connect,$sql); 
$row = mysqli_fetch_array($query);

$mark = $row['mode'];
if($mark == "null"){
  $Normal = "Normal ✅";
  $Markdown = "Markdown";
  $HTML = "HTML";
}
if($mark == "Markdown"){
  $Normal = "Normal";
  $Markdown = "Markdown ✅";
  $HTML = "HTML";
}
if($mark == "HTML"){
   $Normal = "Normal";
  $Markdown = "Markdown";
  $HTML = "HTML ✅";
}

bot('sendmessage',[
    'chat_id'=>$cid,
    'text'=>"⁪⁬",
'parse_mode' => 'markdown',
'reply_markup'=>json_encode([
'KeyboardRemove'=>[],
'remove_keyboard'=>true,
])
]);
bot("deleteMessage",[
"chat_id"=>$cid,
"message_id"=>$mid+1,
]);
bot('sendMessage',[
         'chat_id'=>$cid,
         'text'=>"*Postingiz chiroyli ko'rinishi uchun shrift turlari  

Tanlash uchun kerakli variantni bosing.*

Ma'lumotlar: *📖Shrift bo'yicha qollanma* bo'limida",
      'parse_mode'=>'Markdown',
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>"📖Shrift bo'yicha qollanma ", 'callback_data'=>"qollanma"]],
[['text'=>$Normal,'callback_data'=>'parsemode_null'],['text'=>$Markdown,'callback_data'=>'parsemode_Markdown'],['text'=>$HTML,'callback_data'=>'parsemode_HTML']],
[['text'=>"📡Kanal O'zgartirish🖍", 'callback_data'=>"editkanal"]],
[['text'=>"🏠Bosh menyu", 'callback_data'=>"home"]],
]
    ])
        ]);
}
if(preg_match("/^(parsemode)_(.*)/s",$data)){
   preg_match("/^(parsemode)_(.*)/s",$data,$matchaa);
  $parsemode = $matchaa[2];
mysqli_query($connect,"UPDATE users SET mode='".$parsemode."' WHERE user_id='$callfrid'");
$sql = "SELECT * FROM `users` WHERE `user_id`='$callfrid' LIMIT 1";
$query = mysqli_query($connect,$sql); 
$row = mysqli_fetch_array($query);
$mark = $row['mode'];

if($mark == "null"){
  $Normal = "Normal ✅";
  $Markdown = "Markdown";
  $HTML = "HTML";
}
if($mark == "Markdown"){
  $Normal = "Normal";
  $Markdown = "Markdown ✅";
  $HTML = "HTML";
}
if($mark == "HTML"){
   $Normal = "Normal";
  $Markdown = "Markdown";
  $HTML = "HTML ✅";
}

  bot('editMessagetext',[
         'chat_id'=>$cid2,
'message_id'=>$mid2,
         'text'=>"*Postingiz chiroyli ko'rinishi uchun shrift turlari  

Tanlash uchun kerakli variantni bosing.*

Ma'lumotlar: *📖Shrift bo'yicha qollanma* bo'limida",
      'parse_mode'=>'Markdown',
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>"📖Shrift bo'yicha qollanma ", 'callback_data'=>"qollanma"]],
[['text'=>$Normal,'callback_data'=>'parsemode_null'],['text'=>$Markdown,'callback_data'=>'parsemode_Markdown'],['text'=>$HTML,'callback_data'=>'parsemode_HTML']],
[['text'=>"📡Kanal O'zgartirish🖍", 'callback_data'=>"editkanal"]],
[['text'=>"🏠Bosh menyu", 'callback_data'=>"home"]],
]
    ])
        ]);
}


if($data == "qollanma"){
bot("editMessagetext",[
"chat_id"=>$cid2,
'message_id'=>$mid2,
"text"=>"*Shriftlarni ishlatish bo'yicha qollanma*🔻

❗Eslatma: *Tanlangan shrift har bir postda qoʻllaniladi*",
"parse_mode"=>"markdown",
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>"📍MARKDOWN uchun",'callback_data'=>'mark'],['text'=>"📍HTML uchun",'callback_data'=>'htm']],
[['text'=>"◀Orqaga", 'callback_data'=>"shrift"]],
]
    ])
]);
}
if($data == "view"){
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
$sql = "SELECT * FROM `users` WHERE `user_id`='$callfrid' LIMIT 1";
$query = mysqli_query($connect,$sql); 
$row = mysqli_fetch_array($query);
$mark = $row['mode'];
if($mark == "null"){
  $Normal = "Normal ✅";
  $Markdown = "Markdown";
  $HTML = "HTML";
}
if($mark == "Markdown"){
  $Normal = "Normal";
  $Markdown = "Markdown ✅";
  $HTML = "HTML";
}
if($mark == "HTML"){
   $Normal = "Normal";
  $Markdown = "Markdown";
  $HTML = "HTML ✅";
}

   bot("sendMessage",[
"chat_id"=>$cid2,
"text"=>"*Yuboradigan Postingizni 🔻Rasmdagi ko'rinishda bo'ladi*

[‌‌](https://my54448.myxost.ru/kanal/rasm/view.jpg)
",
"parse_mode"=>"markdown",
'disable_web_page_preview'=>false,
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>"📖Shrift bo'yicha qollanma ", 'callback_data'=>"qollanma"]],
[['text'=>$Normal,'callback_data'=>'parsemode_null'],['text'=>$Markdown,'callback_data'=>'parsemode_Markdown'],['text'=>$HTML,'callback_data'=>'parsemode_HTML']],
[['text'=>"📡Kanal O'zgartirish🖍", 'callback_data'=>"editkanal"]],
[['text'=>"🏠Bosh menyu", 'callback_data'=>"home"]],
]
    ])
]);
}

if($data == "shrift"){
$sql = "SELECT * FROM `users` WHERE `user_id`='$callfrid' LIMIT 1";
$query = mysqli_query($connect,$sql); 
$row = mysqli_fetch_array($query);
$mark = $row['mode'];
if($mark == "null"){
  $Normal = "Normal ✅";
  $Markdown = "Markdown";
  $HTML = "HTML";
}
if($mark == "Markdown"){
  $Normal = "Normal";
  $Markdown = "Markdown ✅";
  $HTML = "HTML";
}
if($mark == "HTML"){
   $Normal = "Normal";
  $Markdown = "Markdown";
  $HTML = "HTML ✅";
}
bot('editMessagetext',[
         'chat_id'=>$cid2,
'message_id'=>$mid2,
         'text'=>"*Postingiz chiroyli ko'rinishi uchun shrift turlari  

Tanlash uchun kerakli variantni bosing.*

Ma'lumotlar: *📖Shrift bo'yicha qollanma* va
*Havolani ko'rish👁* tugmalari ostida",
      'parse_mode'=>'Markdown',
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
      [['text'=>"📖Shrift bo'yicha qollanma ", 'callback_data'=>"qollanma"]],
[['text'=>$Normal,'callback_data'=>'parsemode_null'],['text'=>$Markdown,'callback_data'=>'parsemode_Markdown'],['text'=>$HTML,'callback_data'=>'parsemode_HTML']],
[['text'=>"📡Kanal O'zgartirish🖍", 'callback_data'=>"editkanal"]],
[['text'=>"🏠Bosh menyu", 'callback_data'=>"home"]],
]
    ])
        ]);
}
if($data == "mark"){
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
   bot("sendMessage",[
"chat_id"=>$cid2,
"text"=>"*Yuboradigan postingizni 🔻Rasmdagi ko'rinishda yuborishingiz kerak

Namuna: * `*Yuboradigan postingiz*`

[‌‌](https://t.me/hacker_progi/55427)
",
"parse_mode"=>"markdown",
'disable_web_page_preview'=>false,
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>"📍MARKDOWN uchun",'callback_data'=>'mark'],['text'=>"📍HTML uchun",'callback_data'=>'htm']],
[['text'=>"◀Orqaga", 'callback_data'=>"shrift"]],
]
    ])
]);
}

if($data == "htm"){
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
   bot("sendMessage",[
"chat_id"=>$cid2,
"text"=>"*Yuboradigan postingizni 🔻Rasmdagi ko'rinishda yuborishingiz kerak

Namuna: *
 `<b>Yuboradigan postingiz</b>

<i>Yuboradigan postingiz</i>

<code>Yuboradigan postingiz</code>`

[‌‌](https://t.me/hacker_progi/55428)
",
"parse_mode"=>"markdown",
'disable_web_page_preview'=>false,
     'reply_markup'=>json_encode([
      'inline_keyboard'=>[
[['text'=>"📍MARKDOWN uchun",'callback_data'=>'mark'],['text'=>"📍HTML uchun",'callback_data'=>'htm']],
[['text'=>"◀Orqaga", 'callback_data'=>"shrift"]],
]
    ])
]);
}

if($data == "home"){
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
   bot("sendMessage",[
"chat_id"=>$cid2,
"text"=>"*🏠Bosh menyuga qaytingiz* ",
"parse_mode"=>"markdown",
'disable_web_page_preview'=>false,
     'reply_markup'=>$main,
]);
}

if($data == "editkanal"){
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
$sql = "SELECT * FROM `channel` WHERE `creator`='$callfrid' LIMIT 1";
$query = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($query);
$id = $row['channel_id'];
$name = $row['name'];
$user = $row['user'];
$count = $row['count'];
bot('sendmessage',[
    'chat_id'=>$cid2,
    'text'=>"<b>🔴Oldingi kanal malumoti</b>
📋<b> Nomi</b> $name 👈
📧<b> Useri</b> @$user 👈
🆔<b> Raqami</b> $id
👥<b>A'zolari</b> $count",
'parse_mode' => 'html',
'reply_markup'=>json_encode([ 
        'inline_keyboard'=>[ 
       [['text'=>"✍O'zgartirish", 'callback_data'=>"ozg"]],
       [['text'=>"◀Orqaga", 'callback_data'=>"shrift"]],
       ] 
       ])
]);
}

if($data == "ozg"){
	mysqli_query($connect,"UPDATE users SET step = 'kanali' WHERE user_id = '$callfrid' LIMIT 1");
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
bot('sendmessage',[
        'chat_id'=>$cid2,
     'message_id'=>$mid2,
    'text'=>"‼Yangi kanal o'rnatish uchun🔻

*Kanal userini yuboring yoki kanalingizdan birorta postni Forward qiling*",
'parse_mode' => 'markdown',
'reply_markup'=>json_encode([
'KeyboardRemove'=>[],
'remove_keyboard'=>true,
])
]);
}

if($user['step'] =="kanali"){
if(strpos($tx,"@") !==false){
$us= bot('getChatMembersCount',[
'chat_id'=>$tx,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$tx,
]);
}else{
$forward_from_id = $message->forward_from_chat->id;
$us= bot('getChatMembersCount',[
'chat_id'=>$forward_from_id,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$forward_from_id,
]);
}
$kid = $getchat->result->id;
$kname = $getchat->result->title;
$kuser = $getchat->result->username;
$kty = $getchat->result->type;
$query = mysqli_query($connect,"SELECT * FROM channel WHERE channel_id='".$kid."'");
$tek = mysqli_fetch_assoc($query);
if($tek){
	bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"*🚯Bu kanal oldindan botga o'rnatilgan*",
  'parse_mode'=>'markdown',
'reply_markup'=>$main,
 ]);
	}else{
if($kty == "channel"){
bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"🆗 Kanalingiz haqida malumot!
Nomi➡️ $kname 👈
Useri➡️ @$kuser 👈
ID raqami➡️ $kid
A'zolar soni ➡ $count

✅ Tasdiqlash tugmasi orqali tasdiqlang.",
'parse_mode'=>'html',
 'reply_markup'=>json_encode([ 
        'inline_keyboard'=>[ 
       [['text'=>" ✅ Tasdiqlash ", 'callback_data'=>"kanali|$kid"]],
       ] 
       ])
]);
}
}}

if((stripos($data,"kanali|")!==false)){
$ex = explode("|",$data);
	$px = $ex[1];
 $url = 'https://api.telegram.org/bot'.$token.'/getChatAdministrators?chat_id='.$px;
$us= bot('getChatMembersCount',[
'chat_id'=>$px,
]);
$count = $us->result;
$getchat = bot('getChat', [
'chat_id'=>$px,
]);
$kid = $getchat->result->id;
$kname = $getchat->result->title;
$kuser = $getchat->result->username;
  $result = file_get_contents($url);
  $result = json_decode ($result);
  $ok = $result->ok;
$get = file_get_contents("https://api.telegram.org/bot$token/getChatMember?chat_id=$px&user_id=".$callfrid);
$info = json_decode($get, true);
$you = $info['result']['status'];
if($ok == 'true' && $you == "creator" or $you == "administrator"){
mysqli_query($connect,"UPDATE `channel` SET `channel_id` = '".$px."', name= '".$kname."', count = '".$count."', user = '".$kuser."' WHERE creator = '$callfrid' LIMIT 1");
mysqli_query($connect,"UPDATE users SET step = 'tugadi' WHERE user_id = '$callfrid' LIMIT 1");
bot("deleteMessage",[
"chat_id"=>$cid2,
"message_id"=>$mid2,
]);
bot('sendmessage',[
        'chat_id'=>$cid2,
     'message_id'=>$mid2,
'text'=>"✔<b>Kanalingiz muvaffaqiyatli qoshildi
$px
🆗 Kanalingiz haqida malumot!</b>
📋<b> Nomi </b> $kname 👈
📧<b> Useri</b> @$kuser 👈
🆔<b> Raqami</b> $kid
👥<b>A'zolari</b> $count",
'parse_mode'=>'html',
    'reply_markup'=>$menyu,
]);
}else{
bot('answerCallbackQuery',[ 
        'callback_query_id'=>$qid, 
        'text'=>" 📛Bot yoki siz kanalda admin emassiz! 

Xatoni tog'irlab qayta ✅ Tasdiqlash tugmasini bosing☹️", 
        'show_alert'=>true, 
    ]);  
}
}
#===========(@LiderKoder)=========#

if($tx == "📊 Statistika"){
$query = mysqli_query($connect,"SELECT * FROM users");
$odam = mysqli_num_rows($query);
$query = mysqli_query($connect,"SELECT * FROM channel");
$kanal = mysqli_num_rows($query);
$query = mysqli_query($connect,"SELECT * FROM post WHERE status = 'yes'");
$post = mysqli_num_rows($query);
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"📊 *Bot statistikasi:

👥Barcha foydalanuvchilar:* $odam ta
📡*Barcha kanallar:* $kanal ta
🧾*Aktiv postlar:* $post ta

*Admin: @LiderKoder*

📅$sana ⌚$soat",
'parse_mode'=>'markdown',
]);
}
#===========(@LiderKoder)=========#
if($tx=="📖 Qo'llanma"){
bot('senddocument',[
'document'=>"https://t.me/My_partfolios/57",
'caption'=>"*@ForchannelBot da ishlash videosi!*

`Bot xozirda juda ommalashgan kanalga obuna bo'lmasa javobini, davomini oʻqiy olmaydigan post tayorlab beradi`

Admin: @LiderKoder",
'parse_mode'=>'markdown',
'chat_id'=>$cid,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🤖 Bot yangiliklari","url"=>"https://t.me/my_partfolios"]],
]
]),
]);
}
#===========(@LiderKoder)=========#
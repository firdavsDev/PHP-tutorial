<?php

/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
ob_start();
error_reporting(0);
define('API_KEY','2037076638:AAE7dUofxD08YFpA6tnolmljgmavRX4ombk');  
$admin = "1976823675";
$kanal="-100";

function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
 curl_setopt($ch,CURLOPT_URL,$url);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
 curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
 	var_dump(curl_error($ch));
 }else{
 	return json_decode($res);
}
}


$botir = json_decode(file_get_contents("php://input"));
$message = $botir->message;
$chat_id = $message->chat->id;
$mid = $message->message_id;
$text = $message->text;  
$firstname = $message->chat->first_name;
$lastname = $message->chat->last_name;
$query = $botir->inline_query->query; 
$infid = $botir->inline_query->from->id;
$inid = $botir->inline_query->id;
$incid = $botir->inline_query->chat->id;
$inmid = $botir->inline_query->message->id;
$cqid = $botir->callback_query->id;
$uid= $message->from->id;
$ccid = $botir->callback_query->message->chat->id;
$data = $botir->callback_query->data;
$query=$botir->inline_query->query;
$step=file_get_contents("step/$chat_id.txt");
$reklama=file_get_contents("reklama/reklama.txt");
$mid = $message->message_id;
require ("sql.php");
require ("panel.php");
mkdir(step);
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
$tex="Assalom alaykum😎
Botimizga xush kelibsiz😇
Botimiz orqali inline tarizda ovozli xabar qidirishingiz mumkun🔍
Bazamizni boyitish uchin bizga ovozli xabarlarni ulashing🤝
Ovoz qidirganda topilishi uchun caption ga nomini yozing📝
Dasturchi: @B_R_CoDeR
";

/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
if($text=="/start"){
$result = mysqli_query($connect,"SELECT * FROM users WHERE id = '$chat_id'");
$row = mysqli_fetch_assoc($result);
if(!$row){

mysqli_query($connect, "INSERT INTO users(`id`) VALUES ('$chat_id')");
bot('sendmessage',[
  'chat_id'=>$chat_id,
  'text'=>"$tex
",
'reply_markup'=>json_encode(['inline_keyboard'=>[
        [["text"=>"🔍Ovoz Qidirish😍","switch_inline_query"=>" "],],
        ]
])
]);
}else{
 bot('sendMessage',[
  'chat_id'=>$chat_id,
  'text'=>"$tex

$reklama",
'reply_markup'=>json_encode(['inline_keyboard'=>[
        [["text"=>"🔍Ovoz Qidirish😍","switch_inline_query"=>" "],],
        ]
])
  ]);
}
}
if(isset($message->voice)){
 $file_id = $message->voice->file_id;
	$caption = $message->caption;
$caption=str_replace("'","",$caption);
$caption=str_replace("`","",$caption);
if($caption == NULL){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Voice ga  nom berilmagan.

$reklama",
]);
}else{
mysqli_query($connect, "INSERT INTO data(`id`,`name`) VALUES ('$file_id','$caption')");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Ovoz Bazaga Yuklandi😎",
]);
}
}
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
$query = $botir->inline_query->query;
if (isset($query)){
$query=str_replace("`","",$query);
$query=str_replace("'","",$query);
$sql =mysqli_query($connect,"SELECT * FROM `data` WHERE `name`  LIKE '%$query%' LIMIT 0,150");
while($a = mysqli_fetch_assoc($sql)){
$url = $a['id'];
$name=$a['name'];
$u=$a['iid'];
        $uz [] = ["type" => "voice",
      "id" =>"$u",
      "title"=>"$name",
      "voice_url" => "$url",
      "caption" => "$reklama",
      "parse_mode" => "markdown",];
}
    $key = json_encode($uz);
    bot("answerInlineQuery",[
    "inline_query_id"=>$botir->inline_query->id,
    "cache_time"=>1,
    "results"=>$key,
    ]);
}
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
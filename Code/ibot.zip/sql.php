<?php
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
$servername = "localhost";
$username = "voicebot";
$password = "voicebot";
$connect = new mysqli($servername, $username, $password, $username);
//Ushbu commentga olingan qismi PhpMyAdminga kirib Bajariladi
/*CREATE TABLE IF NOT EXISTS `data` (
  `iid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '@RasmQaniBot',
  `id` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
*/
//👆👆👆👆👆👆👆
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
?>
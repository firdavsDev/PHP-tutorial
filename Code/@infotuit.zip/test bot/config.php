<?php
$servername = "localhost";
$username = "login";
$password = "parol";
$conn = new mysqli($servername, $username, $password, $username);
?>
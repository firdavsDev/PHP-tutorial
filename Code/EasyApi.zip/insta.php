<?php

error_reporting(0);
If($_GET['url']){
$text = $_GET['url'];
$json = base64_decode("aHR0cHM6Ly9hcGkubXVyb2Rqb24tb2ZmLnV6L0luc3RhZ3JhbS9pbmRleC5waHA=");
$api = file_get_contents("$json?url=$text");
$url = json_decode($api, true);
$video = $url['video']['url'];

echo $video;
}

/* Kodni hostga yuklab brauzerdan ko'rasiz va ?url=video_ssilkasi qilib videoni olasiz

 @php_bot_kodlari */
?>
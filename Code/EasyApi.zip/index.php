<?php
header("Content-type: application/json");
require "./parser.php";
error_reporting(0);

function get($url){
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://videograbber.cc/download?url=' . $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}
/* @UzBots_Robot konstruktori boti kanali 
orqali tarqatildi!

@php_bot_kodlari */
if(isset($_GET["url"])){
    $url = $_GET["url"];
    $re = '/(http(s|):|)\/\/(www\.|)yout(.*?)\/(embed\/|watch.*?v=|)([a-z_A-Z0-9\-]{11})/i';
    $JSON = [];
    if(!preg_match($re, $url)){
        $JSON["data"] = [];
        $JSON["ok"] = false;
        $JSON["message"] = "ID(1)";
        print(json_encode($JSON, JSON_PRETTY_PRINT));
        exit(1);
    }
    $html = str_get_html(get($_GET["url"]));
    $tables = $html->find('tr');
    $i=1;
    foreach($tables as $tr){
        $link = $tr->find('a.btn.btn-small.btn-green', 0)->href;
        $quality = $tr->find('td', 0)->plaintext;
        $format = $tr->find('td', 1)->plaintext;
        if($link == null || $quality == null || $format == null)
        continue;
        $JSON["data"][$i]["format"] = $format;
        $JSON["data"][$i]["quality"] = $quality;
        $JSON["data"][$i]["link"] = $link;
        $i++;
    }
    if(count($JSON["data"]) < 2){
        $JSON["data"] = [];
        $JSON["ok"] = false;
        $JSON["message"] = "ID(2)";
        print(json_encode($JSON, JSON_PRETTY_PRINT));
        exit(1);
    }
    $JSON["ok"] = true;
    $JSON["message"] = "SUCCESS";
    print(json_encode($JSON, JSON_PRETTY_PRINT));

// @php_bot_kodlari
}
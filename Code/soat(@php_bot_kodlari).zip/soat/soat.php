<?php
/*
 * @php_bot_kodlari
 * Kanalim: @ESoftUz
 * Saytim: www.e-soft.uz
 * Murojaat uchun: @ESoftUzb
 * @php_bot_kodlari
 */
/* Modulni yuklash */
if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';
$MadelineProto = new \danog\MadelineProto\API('session.madeline');
$MadelineProto->start();

/* Soatni nick, bio'ga yozish va 24 soat online qilish */
$time = date('H:i', strtotime('5 hour'));
$sana = date('d.m.Y',strtotime('5 hour'));
$input = array("😎Bugun sana📆 $sana| Soat⌚️ $time, @php_bot_kodlari");
$rand = array_rand($input);
$bio = "$input[$rand]";
$nick = array("꫞⛧ℬℴℬℵⅈ k⛧꫞","@php_bot_kodlari");
$rand2 = array_rand($nick);
$nickname = "$nick[$rand2]";
$MadelineProto->account->updateProfile(['about'=>$bio, 'first_name'=>$nickname, 'last_name'=> " | $time"]);
$Bool = $MadelineProto->account->updateStatus(['offline'=>false]);
/* Soat rasmini yasash */
header('content-type: image/jpg');
$img = imagecreatefromjpeg('img/logo.jpg');
$font = "font/MyFont.ttf"; 
$white = imagecolorallocate($img, 0, 253, 77);
$soat = date('H:i',strtotime('5 hour'));
$txt = "$soat";
$x = 165;
$y = 366;
imagettftext($img, 110, 0, $x,$y, $white, $font, $txt);
$txt2 = $sana;
$x2 = 196;
$y2 = 448;
imagettftext($img, 44, 0, $x2,$y2, $white, $font, $txt2);
imagejpeg($img,"img/goto.jpg");
/* Eski rasmni o'chirish */
$info = $MadelineProto->get_full_info('me');
$inputPhoto = ['_' => 'inputPhoto', 'id' => $info['User']['photo']['photo_id'], 'access_hash' => $info['User']['access_hash'], 'file_reference' => 'bytes'];
$deletePhoto = $MadelineProto->photos->deletePhotos(['id'=>[$inputPhoto]]);
/* Yangi rasmni yuklash */
$MadelineProto->photos->updateProfilePhoto(['file' =>"img/goto.jpg"]);
unlink("MadelineProto.log");
unlink("session.madeline");
?>
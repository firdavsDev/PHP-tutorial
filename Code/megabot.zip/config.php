<?
# CONFIG
define('BOT_USERNAME', 'username_bot');
define('BOT_TOKEN', 'bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11');
#define('CHAT_ID', -12345);

# DONT CHANGE
define('PATH', __DIR__ . DIRECTORY_SEPARATOR);
define('FILE_DATA', @PATH .'data.json');
define('FILE_LOG', @PATH .'log.txt');

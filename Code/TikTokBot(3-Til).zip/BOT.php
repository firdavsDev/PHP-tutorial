<?php
date_default_timezone_set("asia/Tashkent");

$token = '1869115505:AAGpGcO89_oM2uG2J6ux4SXTV_dMwbldedw';
$admin = ["1337242713","777135975"];

require "Telegram.php";

include ("tgu.php");

$botname = '@UzDownload_Bot';
$kanalid = "-1001320411714";//ochilgan kanal idsini yozing 

$bot = new Telegram($token);

$db = new mysqli('localhost','name303_tiktok', '20040724', 'name303_tiktok');

if ($db->connect_error) {
	
    die('Connect Error (' . $db->connect_errno . ') ' . $db->connect_error);
    
}

function get_step($cidd,$ty,$u="users2"){
global $db;
$roiw = $db->query("SELECT * FROM `".$u."` WHERE `user_id` = '".$cidd."' LIMIT 1")->fetch_array();
return $roiw[$ty];
}
function step($chat_id,$y,$set_2){
global $db;
return $db->query('UPDATE `users2` SET `'.$y.'` = "'.$set_2.'" WHERE `user_id` = "'.$chat_id.'" LIMIT 1');
}
function ustep($chat_id,$y){
global $db;
return $db->query('UPDATE `users2` SET `'.$y.'` = null WHERE `user_id` = "'.$chat_id.'" LIMIT 1');
}
function users_scaner($chat_id){
global $db;
$user_tek_1 = $db->query("SELECT * FROM `users2` WHERE `user_id` = '".$chat_id."' LIMIT 1")->num_rows;
return $user_tek_1;
}

if (isset ($type) and $type == 'private' ) {
if (users_scaner($fid) == 0){
$db->query("INSERT INTO `users2` (`user_id`, `til`,`songi`,`vaqti`,`vid`,`name`) VALUES ('".$fid."', null, '".$v_soat."','".$v_soat."',null,'".$firstname."')");
$unamei=$bot->getChat(["chat_id"=>$fid])["result"]["username"];
if($unamei==false){
$uname="mavjud emas";
}else{
$uname = "@".$bot->getChat(["chat_id"=>$fid])["result"]["username"];
}
}else{
$db->query("UPDATE `users2` SET `songi` = '".$v_soat."',`name` = '".$firstname."' WHERE `user_id` = '".$fid."' LIMIT 1");
} 
}


$uz=json_encode([
   'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"📽Video Yuklash 📥"],['text'=>"👨‍💻Admin"], ],
[['text'=>"⚠️Yordam"],['text'=>"🇺🇿Til"],],
]
]);
$ru=json_encode([
   'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"📽Скачать Видео 📥"],['text'=>"👨‍💻Администратор"],],
[['text'=>"⚠️Помощь"],['text'=>"🇷🇺Язык"],],
]
]);
$en=json_encode([
   'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"📽Download Video 📥"],['text'=>"👨‍💻Administrator "],],
[['text'=>"⚠️Help"],['text'=>"🇺🇲Language"],],
]
]);




Mkdir("step");
mkdir("lang");
$ides=file_get_contents("ids.txt");
$langg=file_get_contents("lang/$fid.txt");
$sterp=file_get_contents("step/$fid.step");


if (isset ($type) and ($type == 'group' || $type == 'supergroup')) {
$bot->leaveChat([
'chat_id' => $chat_id
]);
}
$userids=file_get_contents("userids.txt");
if($type == 'private'){
if(mb_stripos($userids,$fid)!==false){
}else{
file_put_contents("userids.txt","$userids\n$fid");
}
}




if(mb_stripos($tx,"tiktok.com/")!==false){
file_put_contents("step/$fid.step","$tx");
$lang=file_get_contents("lang/$fid.txt");
$waitt=file_get_contents("https://u1151.xvest1.ru/UzDownloads_Bot/Wait.php?set=$lang");
$m = $bot->sendMessage([
'chat_id'=>$fid,
'text'=>$waitt,
'parse_mode'=>'html',
])["result"]["message_id"];
if(mb_stripos($tx,".html") !=false){
$x = trim(explode("?",$tx)[0]);
}else{
$x = trim($tx);
}
$id = $bot->sendMessage([
"chat_id"=>$kanalid,
"text"=>$x
]);
$bot->deleteMessage([
'chat_id'=>$fid,
'message_id'=>$m,
]);
$db->query("INSERT INTO `navbat_rasm` (`user_id`,`name`) VALUES ('$fid','$x')");
exit(); 

}

if(isset($update->channel_post->video)){
$cap = trim(str_replace("Скачано в @ttsavebot","",$update->channel_post->caption));
$roiw = $db->query("SELECT * FROM `navbat_rasm` WHERE `name` LIKE '%".$cap."%' LIMIT 1")->fetch_array();
$user = $roiw["user_id"];
$n = $roiw["name"];
$id = $roiw["id"];
$az = $update->channel_post->video->file_id;
$ssilka=file_get_contents("step/$user.step");
$langg=file_get_contents("lang/$user.txt");
$newss=file_get_contents("https://u1151.xvest1.ru/UzDownloads_Bot/News.php?set=$langg");
$z = $bot->sendVideo(["chat_id"=>$user, "video"=>$az, 'caption'=>"$ssilka\n\n@Uzdownload_bot",
  ]);
$bot->sendMessage([
'chat_id'=>$user,
'text'=>$newss,
'parse_mode'=>'html',]);
$u=$db->query("SELECT * FROM `video` WHERE `name` = '".$n."' LIMIT 1")->num_rows;
if($u == 0){
$db->query("INSERT INTO `video` (`file_id`,`name`) VALUES ('$az','$n')");
}
if($z){
$db->query("DELETE FROM `navbat_rasm` WHERE `id` = '$id'");    
}
}
if($tx=="👨‍💻Administrator"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"@AdvakatUz",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Back"]],
]
]),
]);
exit ();
}
if($tx == "👨‍💻Admin"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"@AdvakatUz",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Orqaga"]],
]
]),
]);
exit ();
}


if($tx == "👨‍💻Администратор"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"@AdvakatUz",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Назад"]],
]
]),
]);
exit ();
}

if($tx=="📽Video Yuklash 📥"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"<b>TikTok yoki Instagram Video manzilini Yuboring</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Orqaga"]],
]
]),
]);
exit ();
}


if($tx=="📽Download Video 📥"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"
<b>Submit a link from a video from TikTok or Instagram</b>
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Back"]],
]
]),
]);
exit ();
}

if($tx=="📽Скачать Видео 📥"){
$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>"
<b>Отправьте ссылку видео из TikTok или Instagram</b>
",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🔙Назад"]],
]
]),
]);
exit ();
}






if(mb_stripos($tx,"instagram.com/")!==false){
$lang=file_get_contents("lang/$fid.txt");
$waitt=file_get_contents("https://u1151.xvest1.ru/UzDownloads_Bot/Wait.php?set=$lang");
$newss=file_get_contents("https://u1151.xvest1.ru/UzDownloads_Bot/News.php?set=$lang");
$yt=$bot->sendMessage([
'chat_id'=>$fid,
'message_id'=>$mid,
'text'=>$waitt,
'parse_mode'=>'html',
])["result"]["message_id"];
$vidurl=file_get_contents("http://u2349.xvest2.ru/Tiktok/InstagramApi.php?url=$tx");
$bot->sendVideo([
"chat_id"=>$fid, 
"video"=>$vidurl,
 'caption'=>$tx."\n\n".$botname,
  ]);
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>$newss,
'parse_mode'=>'html',]);
$bot->deleteMessage([
'chat_id'=>$fid,
'message_id'=>$yt,
]);
$bot->sendVideo([
"chat_id"=>$kanalid, 
"video"=>$vidurl,
 'caption'=>$tx."\n\n".$botname,
  ]);
}




if($tx=="🔙Orqaga" and $langg=="uz"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Bosh Menyu",
'parse_mode'=>'html',
'reply_markup'=>$uz
]);
exit();     
}

if($tx=="🔙Назад" and $langg=="ru"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Главное Меню",
'parse_mode'=>'html',
'reply_markup'=>$ru
]);
exit();     
}

if($tx=="🔙Back" and $langg=="en"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Main Menu",
'parse_mode'=>'html',
'reply_markup'=>$en
]);
exit();     
}


if($tx == "⚠️Help"){
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🤖 @UzDownload_Bot can download videos from <b> TikTok and Instagram </b> for you.

 <b> How to download video: </b> 
▪️1. Go to TikTok or Instagram. 
▪️2. Choose the video that interests you. 
▪️3. Press the ↪️ button or the three dots in the upper right corner. 
▪️4. Click the <code> Copy </code> button. 
▪️5. Send the link to the bot and the bot will send you the video in a few seconds.",
'parse_mode'=>'html',
]);
}


if($tx == "⚠️Помощь"){
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🤖 @UzDownload_Bot может скачивать для вас видео из <b> TikTok и Instagram </b>. 

<b> Как скачать видео: </b> 
▪️1. Зайдите в TikTok или Instagram. 
▪️2. Выберите видео, которое вас интересует. 
▪️3. Нажмите кнопку ↪️ или 3 точки в правом верхнем углу. 
▪️4. Нажмите кнопку «<code> Копировать </code>». 
▪️5. Отправьте ссылку боту, и бот пришлёт вам видео через несколько секунд.",
'parse_mode'=>'html',
]);
}


if($tx == "⚠️Yordam"){
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🤖  @UzDownload_Bot siz uchun <b>“TikTok va Instagram”</b> dan video yuklab beraoladi.

<b>Video qanday yuklab olinadi:</b>
  ▪️1. TikTok yoki Instagram  programmasiga o'ting.
  ▪️2. Sizni qiziqtirgan video tanlang.
  ▪️3. ↪️ tugmachasini yoki yuqori o'ng burchakdagi uchta nuqtani bosing.
  ▪️4. «<code>Скопировать</code>» tugmasini bosing.
  ▪️5. Ssilkani botga yuboring va bot bir necha soniya ichida sizga videoni yuboradi.",
'parse_mode'=>'html',
]);
}

if($tx == "/start" and $langg=="uz"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Bosh Menyu",
'parse_mode'=>'html',
'reply_markup'=>$uz,
]);
}
if($tx == "/start" and $langg=="ru"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Главное Меню",
'parse_mode'=>'html',
'reply_markup'=>$ru,
]);
}
if($tx == "/start" and $langg=="en"){    
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🏠Main Menu",
'parse_mode'=>'html',
'reply_markup'=>$en,
]);
}




if(isset($tx) and $tx=="/start"){
if(mb_stripos($ides,$fid)!==false){
}else{
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"🇺🇿Tilni Tanlang.
🇷🇺Выберите Язык. 
🇺🇲Choose Language. ",
'parse_mode'=>'html',
"reply_markup"=>json_encode([
   'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🇺🇿O'zbek Tili"],['text'=>"🇷🇺Русский язык"],],
[['text'=>"🇺🇲English"],],
]
]),
]);
file_put_contents("step/$fid.step","lang");
exit();     
}
}


if(($tx == "🇺🇿O'zbek Tili" or $tx == "🇺🇲English" or $tx == "🇷🇺Русский язык") and $sterp=="lang"){    
$tx4=str_replace("🇺🇿O'zbek Tili","✅O'zbek Tili tanlandi.",$tx);
$tx4=str_replace("🇷🇺Русский язык","✅Выбран Русский язык.",$tx4);
$tx4=str_replace("🇺🇲English","✅English language is selected.",$tx4);
$langg=str_replace("🇺🇿O'zbek Tili","uz",$tx);
$langg=str_replace("🇷🇺Русский язык","ru",$langg);
$langg=str_replace("🇺🇲English","en",$langg);
$keyb=str_replace("🇺🇿O'zbek Tili","$uz",$tx);
$keyb=str_replace("🇷🇺Русский язык","$ru",$keyb);
$keyb=str_replace("🇺🇲English","$en",$keyb);
$startt=str_replace("🇺🇿O'zbek Tili","Salom🖐, <a href='tg://user?id=$fid'>$firstname $lastname</a>
Ushbu Bot Orqali  <b>TikTok</b>dan Videoni Suv Belgisiz Yuklab Olishi Mumkin.

🤖@UzDownload_Bot",$tx);
$startt=str_replace("🇷🇺Русский язык","Привет🖐, <a href='tg://user?id=$fid'>$firstname $lastname</a>
Этот бот может загружать видео с TikTok без водяных знаков. 

🤖 @UzDownload_Bot",$startt);
$startt=str_replace("🇺🇲English","Hi 🖐, <a href='tg://user?id=$fid'>$firstname $lastname</a>

This Bot Can Upload Video From TikTok Without Watermark. 

🤖 @UzDownload_Bot",$startt);
file_put_contents("lang/$fid.txt",$langg);
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>$tx4,
'parse_mode'=>'html',
]);file_put_contents("ids.txt","$ides\n$fid");
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>$startt,
'parse_mode'=>'html',
'reply_markup'=>$keyb,
]);
unlink("step/$fid.step");
}

if($tx=="🇺🇿Til" or $tx=="🇷🇺Язык" or $tx=="🇺🇲Language"){
$choslang=str_replace("🇺🇿Til","🇺🇿Tilni Tanlang.",$tx);
$choslang=str_replace("🇷🇺Язык","🇷🇺Выберите Язык. ",$choslang);
$choslang=str_replace("🇺🇲Language","🇺🇲Choose Language. ",$choslang);
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>$choslang,
'parse_mode'=>'html',
"reply_markup"=>json_encode([
   'resize_keyboard'=>true,
'keyboard'=>[
  [['text'=>"🇺🇿O'zbek Tili"],['text'=>"🇷🇺Русский язык"],],
[['text'=>"🇺🇲English"],],
]
]),
]);
file_put_contents("step/$fid.step","editlang");
exit();     
}



if(($tx == "🇺🇿O'zbek Tili" or $tx == "🇺🇲English" or $tx == "🇷🇺Русский язык") and $sterp=="editlang"){    
$tx4=str_replace("🇺🇿O'zbek Tili","✅O'zbek Tili tanlandi.",$tx);
$tx4=str_replace("🇷🇺Русский язык","✅Выбран Русский язык.",$tx4);
$tx4=str_replace("🇺🇲English","✅English language is selected.",$tx4);
$langg=str_replace("🇺🇿O'zbek Tili","uz",$tx);
$langg=str_replace("🇷🇺Русский язык","ru",$langg);
$langg=str_replace("🇺🇲English","en",$langg);
$keyb=str_replace("🇺🇿O'zbek Tili","$uz",$tx);
$keyb=str_replace("🇷🇺Русский язык","$ru",$keyb);
$keyb=str_replace("🇺🇲English","$en",$keyb);
$startt=str_replace("🇺🇿O'zbek Tili","🏠Bosh Menyu",$tx);
$startt=str_replace("🇷🇺Русский язык","🏠Главное Меню",$startt);
$startt=str_replace("🇺🇲English","🏠Main Menu",$startt);
file_put_contents("lang/$fid.txt",$langg);
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>$tx4."\n\n".$startt,
'parse_mode'=>'html',
'reply_markup'=>$keyb,
]);
}


if(isset($tx) and $tx=="/stat" and in_array($fid,$admin)){
$stat = $db->query("SELECT * FROM `users2`")->num_rows;
$stat2 = $db->query("SELECT * FROM `video`")->num_rows;
$bot->sendMessage([
'chat_id'=>$fid,
'text'=>"📊<b>┌ STATISTIKA
👥└ A`zolar: <code>$stat</code>
🎞└ Saqlab olingan Videolar: <code>$stat2</code></b>",
'parse_mode'=>'html',
]);
exit();
}



if((mb_stripos($tx,"/send")!==false) and in_array($fid,$admin)){
$txt3=explode("/send",$tx)[1];
if($txt3){
$get = file_get_contents("userids.txt");
$ex = explode("\n",$get);
 foreach ($ex as $user) {
$sended3=$bot->sendMessage([
 'chat_id'=>$user,
'text'=>$txt3,
'parse_mode'=>'html',
 ]);
 unlink("admin.txt");
 }}}
 if($sended3){
 $bot->sendMessage([
 'chat_id'=>$fid,
 'text'=>"Barcha Foydalanuvchilarga Xabar Yuborildi",
 ]);
unlink("admin.txt");
 }
 



?>
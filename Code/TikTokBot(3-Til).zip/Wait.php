<?php
$get=$_GET['set'];

if($get=="uz"){
$e="Iltimos kuting...";
}

if($get=="ru"){
$e="Пожалуйста подождите...";
}

if($get=="en"){
$e="Please Wait...";
}

echo $e;
?>



<?php
$conn = mysqli_connect("localhost", "name303_tiktok", "20040724","name303_tiktok");
if(!$conn){
  die("xato: ".mysqli_connect_error());
}else{
  echo "Ulanildi</br>";
}

$query3 = mysqli_query($conn,"create table users2(
id int(20) auto_increment primary key,
name varchar(400),
user_id varchar(100),
vaqti varchar(200),
til varchar(200),
songi varchar(200),
vid varchar(200)
)");

$query4 = mysqli_query($conn,"create table navbat_rasm(
id int(20) auto_increment primary key,
user_id varchar(400),
name varchar(400)
)");

$query5 = mysqli_query($conn,"create table video(
id int(20) auto_increment primary key,
file_id varchar(400),
name varchar(400)
)");


if($query3){
echo "Jadval yaratildi</br>";
}else{
echo "Xato $conn->error";
}
if($query4){
echo "Jadval yaratildi</br>";
}else{
echo "Xato $conn->error";
}

if($query5){
echo "Jadval yaratildi</br>";
}else{
echo "Xato $conn->error";
}



?>
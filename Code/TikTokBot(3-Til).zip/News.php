<?php
$get=$_GET['set'];

if($get=="uz"){
$e="Botning barcha yangiliklaridan xabardor bo'lish uchun @UzSaveNews kanaliga obuna bo'ling. ";
}

if($get=="ru"){
$e="Подпишитесь на канал @UzSaveNews, чтобы быть в курсе всех новостей бота.";
}

if($get=="en"){
$e="Subscribe to the @UzSaveNews channel to keep abreast of all the news of the bot. ";
}

echo $e;
?>



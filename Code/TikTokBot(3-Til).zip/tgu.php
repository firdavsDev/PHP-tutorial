<?php
$update = json_decode(file_get_contents("php://input"));
if(!empty($update)){
	if(!empty($update->message)){
		if(!empty($update->message->contact->user_id)){
			$contact_id = $update->message->contact->user_id;
		}
		if(!empty($update->message->contact->phone_number)){
			$phone_number = $update->message->contact->phone_number;
		}
		if(!empty($update->message->text)){
			$tx = $update->message->text;
		}
		if(!empty($update->message->caption)){
			$cap = $update->message->caption;
		}
		if(!empty($update->message->message_id)){
			$mid = $update->message->message_id;
		}
		if(!empty($update->message->from->id)){
			$fid = $update->message->from->id;
		}
		if(!empty($update->message->photo)){
			$photo = $update->message->photo;
			$file_id = $photo[count($photo) - 1]->file_id; 
		}
		if(!empty($update->message->video)){
			$video = $update->message->video;
			$file_id = $video->file_id; 
		}
		if(!empty($update->message->audio)){
			$audio = $update->message->audio;
			$file_id = $audio->file_id; 
		}
		if(!empty($update->message->animation)){
			$animation = $update->message->animation;
			$file_id = $animation->file_id; 
		}
		if(!empty($update->message->sticker)){
			$sticker = $update->message->sticker;
			$file_id = $sticker->file_id; 
		}
		if(!empty($update->message->voice)){
			$voice = $update->message->voice;
			$file_id = $voice->file_id; 
		}
		if(!empty($update->message->video_note)){
			$video_note = $update->message->video_note;
			$file_id = $video_note->file_id; 
		}
		if(!empty($update->message->document)){
			$document = $update->message->document;
			$file_id = $document->file_id; 
		}
		if(!empty($update->message->from->username)){
			$username = $update->message->from->username;
		}
		if(!empty($update->message->from->first_name)){
			$firstname = $update->message->from->first_name;
		}
		if(!empty($update->message->from->last_name)){
			$lastname = $update->message->from->last_name;
		}
		if(!empty($update->message->chat->id)){
			$chat_id = $update->message->chat->id;
		}
		if(!empty($update->message->chat->type)){
			$type = $update->message->chat->type;
		}
		if(!empty($update->message->entities[0])){
			$entities = $update->message->entities[0];
		}
		if(!empty($update->message->entities[0]->type)){
			$etype = $update->message->entities[0]->type;
		}
		if(!empty($update->message->caption_entities[0])){
			$centities = $update->message->caption_entities[0];
		}
		if(!empty($update->message->caption_entities[0]->type)){
			$cetype = $update->message->caption_entities[0]->type;
		}
		if(!empty($update->message->new_chat_member)){
			$newm = $update->message->new_chat_member;
		}
		if((!empty($update->message->chat->type)) and ($update->message->chat->type == "private")) {
			if(!empty($update->message->chat->first_name)){
				$firstname = $update->message->chat->first_name;
			}
			if(!empty($update->message->chat->last_name)){
				$lastname = $update->message->chat->last_name;
			}
			if(!empty($update->message->chat->username)){
				$username = $update->message->chat->username;
			}
		}
		if((!empty($update->message->chat->type)) and ($update->message->chat->type == "group")) {
			if(!empty($update->message->chat->title)){
				$title = $update->message->chat->title;
			}
			if(!empty($update->message->chat->username)){
				$username = $update->message->chat->username;
			}
		}
		if((!empty($update->message->chat->type)) and ($update->message->chat->type == "supergroup")) {
			if(!empty($update->message->chat->title)){
				$title = $update->message->chat->title;
			}
			if(!empty($update->message->chat->username)){
				$username = $update->message->chat->username;
			}
		}
	}
	if(!empty($update->callback_query)){
		if(!empty($update->callback_query->id)){
			$call_id = $update->callback_query->id;
		}
		if(!empty($update->callback_query->message->message_id)){
			$mid = $update->callback_query->message->message_id;
		}
		if(!empty($update->callback_query->from->id)){
			$fid = $update->callback_query->from->id;
		}
		if(!empty($update->callback_query->from->username)){
			$username = $update->callback_query->from->username;
		}
		if(!empty($update->callback_query->from->first_name)){
			$firstname = $update->callback_query->from->first_name;
		}
		if(!empty($update->callback_query->from->last_name)){
			$lastname = $update->callback_query->from->last_name;
		}
		if(!empty($update->callback_query->data)){
			$data = $update->callback_query->data;
		}
		if(!empty($update->callback_query->message->chat->id)){
			$chat_id = $update->callback_query->message->chat->id;
		}
		if(!empty($update->callback_query->message->chat->type)){
			$type = $update->callback_query->message->chat->type;
		}
		if((!empty($update->callback_query->message->chat->type)) and ($update->callback_query->message->chat->type == "private")) {
			if(!empty($update->callback_query->message->chat->first_name)){
				$firstname = $update->callback_query->message->chat->first_name;
			}
			if(!empty($update->callback_query->message->chat->last_name)){
				$lastname = $update->callback_query->message->chat->last_name;
			}
			if(!empty($update->callback_query->message->chat->username)){
				$username = $update->callback_query->message->chat->username;
			}
		}
		if((!empty($update->callback_query->message->chat->type)) and ($update->callback_query->message->chat->type == "group")) {
			if(!empty($update->callback_query->message->chat->title)){
				$title = $update->callback_query->message->chat->title;
			}
			if(!empty($update->callback_query->message->chat->username)){
				$username = $update->callback_query->message->chat->username;
			}
		}
		if((!empty($update->callback_query->message->chat->type)) and ($update->callback_query->message->chat->type == "supergroup")) {
			if(!empty($update->callback_query->message->chat->title)){
				$title = $update->callback_query->message->chat->title;
			}
		}
	}

	if(!empty($update->inline_query)){
		if(!empty($update->inline_query->query)){
			$iquer = $update->inline_query->query;
		}
		if(!empty($update->inline_query->from->id)){
			$ifid = $update->inline_query->from->id;
		}
		if(!empty($update->inline_query->from->username)){
			$username = $update->inline_query->from->username;
		}
		if(!empty($update->inline_query->from->first_name)){
			$firstname = $update->inline_query->from->first_name;
		}
	}
	if(!empty($update->edited_message)){
		if(!empty($update->edited_message->text)){
			$tx = $update->edited_message->text;
		}
		if(!empty($update->edited_message->message_id)){
			$mid = $update->edited_message->message_id;
		}
		if(!empty($update->edited_message->from->id)){
			$fid = $update->edited_message->from->id;
		}
		if(!empty($update->edited_message->from->username)){
			$username = $update->edited_message->from->username;
		}
		if(!empty($update->edited_message->from->first_name)){
			$firstname = $update->edited_message->from->first_name;
		}
		if(!empty($update->edited_message->from->last_name)){
			$lastname = $update->edited_message->from->last_name;
		}
		if(!empty($update->edited_message->chat->id)){
			$chat_id = $update->edited_message->chat->id;
		}
		if(!empty($update->edited_message->chat->type)){
			$type = $update->edited_message->chat->type;
		}
		if(!empty($update->edited_message->entities[0])){
			$entities = $update->edited_message->entities[0];
		}
		if(!empty($update->edited_message->entities[0]->type)){
			$etype = $update->edited_message->entities[0]->type;
		}
		if(!empty($update->edited_message->caption_entities[0])){
			$centities = $update->edited_message->caption_entities[0];
		}
		if(!empty($update->edited_message->caption_entities[0]->type)){
			$cetype = $update->edited_message->caption_entities[0]->type;
		}
	}
}
?>
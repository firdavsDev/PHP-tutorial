<?php

$servername = "localhost";
$username = "voicee";
$password = "parilzJ6mU0cZ6nbW3g";
$connect = new mysqli($servername, $username, $password, $username);

mysqli_query($connect,"CREATE TABLE `data` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `id` text NOT NULL,
)");

/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 
?>
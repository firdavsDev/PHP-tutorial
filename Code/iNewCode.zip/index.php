<?php
/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 

ob_start();
error_reporting(0);
define('API_KEY','Token');  
$admin = "1976823675";
$kanal="@individual_coder";
$bot="Global_SMMRoBot";
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
 curl_setopt($ch,CURLOPT_URL,$url);
 curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
 curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
 $res = curl_exec($ch);
 if(curl_error($ch)){
 	var_dump(curl_error($ch));
 }else{
 	return json_decode($res);
}
}


$botir = json_decode(file_get_contents("php://input"));
$message = $botir->message;
$doc = $message->document;
$file_id = $doc->file_id;
$file_name = $doc->file_name;
$size = $doc->file_size;
$dtype= $doc->mime_type;

$chat_id = $message->chat->id;
$mid = $message->message_id;
$text = $message->text;  
$firstname = $message->chat->first_name;
$lastname = $message->chat->last_name;
$query = $botir->inline_query->query; 
$infid = $botir->inline_query->from->id;
$inid = $botir->inline_query->id;
$incid = $botir->inline_query->chat->id;
$inmid = $botir->inline_query->message->id;
$cqid = $botir->callback_query->id;
$uid= $message->from->id;
$ccid = $botir->callback_query->message->chat->id;
$data = $botir->callback_query->data;
$query=$botir->inline_query->query;
$step=file_get_contents("step/$chat_id.txt");
$reklama=file_get_contents("reklama/reklama.txt");
$mid = $message->message_id;
require ("sql.php");

if($text=="/start"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"$firstname, Faylni yuklash uchun $kanal kanaliga kirib kerakli ilovani tanlang!",
]);
}

if(isset($message->document) and $chat_id==$admin){
$top=mysqli_query($connect,"SELECT * FROM `data` ORDER BY `iid` DESC LIMIT 1");
$a = mysqli_fetch_assoc($top);
$soni=$a['iid'];
$s=$soni+1;

 $file_id = $message->document->file_id;
	$caption = $message->caption;
mysqli_query($connect, "INSERT INTO data(`id`,`name`) VALUES ('$file_id','$file_name')");
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Document kanalga joylandi😎",
]);

bot('sendPhoto',[
  'chat_id'=>$kanal,
  'photo'=>"https://t.me/Individual_Programmer/13",
  'caption'=>"$caption
  
  ✍️Fayl nomi: $file_name
  📲Fayl Hajmi: $size
  🕵️‍♂️Fayl tipi: $dtype

  ",
  'reply_markup'=>json_encode([
    'inline_keyboard'=>[
      [['text'=>"📥Yuklab olish📥",'url'=>"https://t.me/$bot?start=$s"],],
      ]
    ])
  ]);
}
if(mb_stripos($text,"/start")!==false){
$exp=explode(" ",$text);
$link=$exp[1];
$resul= mysqli_query($connect,"SELECT * FROM `data` WHERE `iid` = '$link'");
$a = mysqli_fetch_assoc($resul);
$file= $a['id'];
$name=$a['name'];
 bot('sendDocument',[
   'document'=>$file,
   'chat_id'=>$chat_id,
   'caption'=>"$name",
   ]);
}

/*Ushbu kod Botir Raimqulov tomonidan tuzildi
Tarqatishda yordam bergan: https://t.me/KingsOfPhp kanaliga raxmat 
Kanalimiz: @Individual_Programmer
Tuzuvchi:@B_R_CoDeR
Manbaasiz olmanglar insofli insofsizlar
*/ 